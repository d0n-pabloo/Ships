﻿namespace Statki
{
    internal class Program
    {
        static void Main(string[] args)
        {
            GameManager.Inst.StartGame();
        }
    }
}